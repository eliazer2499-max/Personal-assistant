# My app
Run npm start