// Runtime configuration from environment (written by install.sh to /etc/myassistant/env).
// No secrets live here: keys and tokens are stored encrypted in the database.
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const APP_DIR = path.resolve(here, '..');
export const VERSION = fs.readFileSync(path.join(APP_DIR, 'VERSION'), 'utf8').trim();

const env = process.env;
export const cfg = {
  dataDir: env.MA_DATA_DIR || '/var/lib/myassistant',
  port: parseInt(env.MA_PORT || '8787', 10),
  host: env.MA_HOST || '127.0.0.1',
  publicUrl: (env.MA_PUBLIC_URL || 'http://127.0.0.1:8787').replace(/\/+$/, ''),
  workspace: env.MA_WORKSPACE || '/srv/myassistant/workspace',
  sitesDir: env.MA_SITES_DIR || '/srv/myassistant/sites',
  sandboxUser: env.MA_SANDBOX_USER === undefined ? 'ma-run' : env.MA_SANDBOX_USER,
  updateUnit: env.MA_UPDATE_UNIT || 'myassistant-update.service',
  releaseBase: (env.MA_RELEASE_BASE || 'https://abish-assistant-v2.sites.tab.bot').replace(/\/+$/, ''),
  // 2.3.1: where updates come from, in order: his own address (GitHub Pages from the repo's /docs), the same folder
  // on raw.githubusercontent.com, then the release site above. Tests never reach the internet: in test mode only the release base.
  updateSource: env.MA_UPDATE_SOURCE || (env.MA_TEST_MODE === '1' ? (env.MA_RELEASE_BASE || '').replace(/\/+$/, '') : 'https://updates.personalassistance.soft-tech.net'),
  updateFallbacks: env.MA_UPDATE_FALLBACKS !== undefined ? env.MA_UPDATE_FALLBACKS.split(',').map(s => s.trim()).filter(Boolean)
    : (env.MA_TEST_MODE === '1' ? [] : ['https://raw.githubusercontent.com/eliazer2499-max/Personal-assistant/main/docs']),
  testMode: env.MA_TEST_MODE === '1',
  mockModule: env.MA_MOCK_MODULE || '',
  googleBase: env.MA_GOOGLE_BASE || '',     // test override for all Google endpoints
  geminiBase: env.MA_GEMINI_BASE || '',   // test override
  cloudflareBase: env.MA_CLOUDFLARE_BASE || '',   // 2.3.11 test override (Cloudflare API base, ends in /client/v4)
  githubApi: (env.MA_GITHUB_API || 'https://api.github.com').replace(/\/+$/, ''),                      // 2.3.7: test override
  cloudflareApi: (env.MA_CLOUDFLARE_API || 'https://api.cloudflare.com/client/v4').replace(/\/+$/, ''),  // 2.3.7: test override
  telegramBase: env.MA_TELEGRAM_BASE || 'https://api.telegram.org',
  graphBase: env.MA_GRAPH_BASE || 'https://graph.facebook.com',
  sshBin: env.MA_SSH_BIN || 'ssh',
  tickMs: parseInt(env.MA_TICK_MS || '20000', 10),
  // WhatsApp Agent Platform (2.2). The test knobs only exist so tests do not wait a real minute.
  waAgentBase: env.MA_WA_AGENT_BASE || 'https://api.whatsapp.com/agent/v1',
  waAgentPollTimeout: env.MA_WA_AGENT_POLL_TIMEOUT ? parseInt(env.MA_WA_AGENT_POLL_TIMEOUT, 10) : 20,
  waAgentMinIntervalMs: env.MA_WA_AGENT_MIN_INTERVAL_MS ? parseInt(env.MA_WA_AGENT_MIN_INTERVAL_MS, 10) : undefined,
  waAgentWindowMs: env.MA_WA_AGENT_WINDOW_MS ? parseInt(env.MA_WA_AGENT_WINDOW_MS, 10) : 60000,
  waAgentBackoffMs: env.MA_WA_AGENT_BACKOFF_MS ? parseInt(env.MA_WA_AGENT_BACKOFF_MS, 10) : 2000,
  // 2.3.19: Settings → Main address. The other addresses this server answers on (installer: MA_EXTRA_DOMAINS), the
  // web server's file (to see hosts added there by hand), and where to learn this server's public IP. Test knobs only in test mode.
  extraDomains: (env.MA_EXTRA_DOMAINS || '').split(',').map(s => s.trim()).filter(Boolean),
  caddyFile: env.MA_CADDYFILE || '/etc/caddy/Caddyfile',
  ipEcho: env.MA_IP_ECHO !== undefined ? env.MA_IP_ECHO : (env.MA_TEST_MODE === '1' ? '' : 'https://api.ipify.org'),
  testDns: env.MA_TEST_MODE === '1' && env.MA_TEST_DNS ? JSON.parse(env.MA_TEST_DNS) : null,
  testProbe: env.MA_TEST_MODE === '1' && env.MA_TEST_PROBE ? JSON.parse(env.MA_TEST_PROBE) : null,
  waAgentConflictMs: env.MA_WA_AGENT_CONFLICT_MS ? parseInt(env.MA_WA_AGENT_CONFLICT_MS, 10) : 60000,
};
export function isHttps() { return cfg.publicUrl.startsWith('https://'); }
export function publicHost() { try { return new URL(cfg.publicUrl).host; } catch { return 'localhost'; } }
